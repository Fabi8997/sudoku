import java.io.*;
import java.net.*;
import java.nio.file.*;
import javax.xml.*;
import javax.xml.transform.stream.*;
import javax.xml.validation.*;
import org.xml.sax.*;


public class ServerLogGUI {
    private static final String percorsoXML = "./myfiles/log.xml";
    private static final String percorsoXSD = "./myfiles/validazione.xsd";
    
    public static void main(String[] args) throws IOException {
        //MessaggioDiLog msg = null;
        try (   ServerSocket servs = new ServerSocket(8080);){
            while(true){
                try{    Socket sd = servs.accept();
                        DataInputStream din = new DataInputStream(sd.getInputStream());                       
                        String msg = din.readUTF() + "\n";
                        validaXML(msg);
                        System.out.println(msg);
                        Files.write(Paths.get(percorsoXML), msg.getBytes(), StandardOpenOption.APPEND);
                }catch(Exception e){e.printStackTrace();}
            }
        }catch(Exception e){e.printStackTrace();}
    }
    
    private static void validaXML(String msg){
         
        try {  
            SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);       
            Schema s = sf.newSchema(new StreamSource(new File(percorsoXSD)));
            s.newValidator().validate(new StreamSource(new StringReader(msg)));
        } catch (Exception e) {
            if (e instanceof SAXException) 
                System.out.println("Errore di validazione: " + e.getMessage());
            else
                System.out.println(e.getMessage());    
        }  
    }
}
