import java.io.*;


public class DatiPartitaSalvata implements Serializable{
    public String nomeUtente;
    public Campo campoAttuale;
    public int erroriAttuali;
    public int punteggioAttuale;
    public int minuti;
    public int secondi;
    public boolean aiutoAttuale;
    public boolean datiValidi;
    
    DatiPartitaSalvata(){
        datiValidi = false;
        punteggioAttuale = 0;
        minuti = 0;
        secondi = 0;
        erroriAttuali = 0;       
    }
}
