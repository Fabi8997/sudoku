
import java.io.*;

public class DatiConfigurazione implements Serializable{
    public String font;
    public int dimensioni;
    public String coloreSfondo;
    public String ipClient;
    public String ipServerLog;
    public int portaServer;
    public String nomeUtenteMYSQL;
    public String passwordMYSQL;
    public int erroriConsentiti;
    public String percorsoCache;
    public int numeroRigheArchivio;
    public Campo[] campiDaGioco;    
}
