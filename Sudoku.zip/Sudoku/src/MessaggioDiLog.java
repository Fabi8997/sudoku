import java.io.*;
import java.text.*;
import java.util.*;

public class MessaggioDiLog implements Serializable{
    private final String nomeApplicazione;
    private final String indirizzoIPClient;
    private final String data;
    private final String ora;
    private final String etichettaEvento;
    
    public MessaggioDiLog( String ipClient, String etichetta){
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat formatter2= new SimpleDateFormat("HH:mm:ss");
        data = formatter.format(date);
        ora = formatter2.format(date);
        
        nomeApplicazione = "Sudoku";
        indirizzoIPClient = ipClient;
        etichettaEvento = etichetta;
    }
}

