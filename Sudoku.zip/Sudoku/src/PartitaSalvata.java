import java.io.*;


public class PartitaSalvata {
    private final String percorsoCache;
    
    PartitaSalvata(String percorso){
        percorsoCache = percorso;
    }
    
    public void salvaPartitaBin(DatiPartitaSalvata dati){
        try (ObjectOutputStream ooutf = new ObjectOutputStream(new FileOutputStream(percorsoCache))){
                ooutf.writeObject(dati);
        } catch (IOException ex) {
            System.out.println("errore: impossibile salvare la partita!");
            ex.printStackTrace();
        }
    }
    
   public DatiPartitaSalvata caricaPartitaBin(){
   
    DatiPartitaSalvata dati = new DatiPartitaSalvata();
    try (ObjectInputStream oinf = new ObjectInputStream(new FileInputStream(percorsoCache))){
                dati = (DatiPartitaSalvata)oinf.readObject();
        } catch (Exception ex) {
            System.out.println("errore: impossibile caricare la partita!");
            dati.datiValidi = false;
        }
    
    return dati;
   }
}
