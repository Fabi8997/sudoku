import javafx.beans.property.*;

public class Utente {
    private final SimpleStringProperty nomeUtente;
    private final SimpleIntegerProperty punteggio;
    private final SimpleIntegerProperty posizione;
    
    Utente(String utente, int punteggio, int posizione){
        nomeUtente = new SimpleStringProperty(utente);
        this.punteggio = new SimpleIntegerProperty(punteggio);
        this.posizione = new SimpleIntegerProperty(posizione);
    }
    
    public String getNomeUtente(){
        return nomeUtente.get(); 
    }
    
    public int getPunteggio(){ 
        return punteggio.get(); 
    }
    
    public int getPosizione(){
        return posizione.get();
    }
}
