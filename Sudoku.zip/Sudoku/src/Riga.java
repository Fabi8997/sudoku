
import java.io.Serializable;

public class Riga implements Serializable{
    public int[] valori;
}
