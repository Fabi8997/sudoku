import java.io.*;

public class Campo implements Serializable {
    
    public Riga[] righeSoluzione;
    public Riga[] righeAttuali;

    
    public boolean inserisciValore(int valore, int riga, int colonna){
        if(righeSoluzione[riga].valori[colonna] == valore){
            righeAttuali[riga].valori[colonna] = valore;           
            return true;
        }else{
            return false;
        }
    }
    
    public boolean campoCompletato(){
        for(int i = 0; i < 9; i++){
            for(int j = 0; j < 9; j++){
                if(righeAttuali[i].valori[j] != righeSoluzione[i].valori[j])
                    return false;
            }
        }
        return true;
    }
    
    public int[][] getGrigliaAttuale(){
        
        int[][] griglia = new int[9][9];
        for(int i = 0; i < 9; i++){
            for(int j = 0; j < 9; j++){
                griglia[i][j] = righeAttuali[i].valori[j];
            }
        }
        return griglia;
    }
    
    public int[][] getGrigliaSoluzione(){
        
        int[][] griglia = new int[9][9];
        for(int i = 0; i < 9; i++){
            for(int j = 0; j < 9; j++){
                griglia[i][j] = righeSoluzione[i].valori[j];
            }
        }
        return griglia;
    }
}
