import com.thoughtworks.xstream.*;
import java.io.*;
import java.net.*;


public class EventoLogGui {
    private final String ipServer;
    private final int portaServer;
    
    public EventoLogGui(String ip, int porta){
        ipServer = ip;
        portaServer = porta;
    }
    
    public void inviaEvento(MessaggioDiLog msg){
        XStream xs = new XStream();
        String x = xs.toXML(msg);
        
        try ( DataOutputStream dout = 
          new DataOutputStream( (new Socket(ipServer,portaServer) ).getOutputStream())
        ) { dout.writeUTF(x);} catch (Exception e) {e.printStackTrace();}
    }
}
