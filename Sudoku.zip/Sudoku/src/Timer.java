import javafx.animation.*;
import javafx.event.*;
import javafx.scene.control.*;
import javafx.util.*;

public class Timer {

    private final Timeline timeline;
    public int secondi;
    public int minuti;
    public Label tempo;
    EventHandler eventhandler = new EventHandler() {    // (01)
            @Override
            public void handle(Event event) {
                secondi++;
                if(secondi == 60){
                    secondi = 0;
                    minuti++;
                }
                aggiornaTempo();
            }
        };
    
    Timer(Label t){ // (2)
        timeline = new Timeline();
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.getKeyFrames().add(new KeyFrame(Duration.millis(1000),eventhandler));
        tempo = t;
        aggiornaTempo();
        }
    
    
    public void aggiornaTempo(){    // (3)
        String m = "00";
        String s = "00"; 
        
        if(secondi < 10){
            s = "0" + Integer.toString(secondi);
        }else{
            s = Integer.toString(secondi);
        }
        
        if(minuti < 10){
            m = "0" + Integer.toString(minuti);
        }else{
            m = Integer.toString(minuti);
        }
        tempo.setText("Tempo: " +m + ":" + s);
    }
    
    public void startTempo(){
        timeline.play();
    }
    
    public void stopTempo(){
        timeline.stop();
    }
    
    public void setTempo(int m, int s){
        secondi = s;
        minuti = m;
        aggiornaTempo();
    }

}


/*
Note:
(1) Gestisce cosa fare ad ogni keyFrame, incrementa i secondi e gestisce 
    l'incremento dei minuti, inoltre salva in una Label con il tempo formattato
(2) Creo una timeline scandita da un numero indefinito di eventi che si ripetono
    ogni 1000 ms
(3) Formatta il tempo dato in secondi e minuti come interi, in un formato del
    tipo: mm:ss
*/