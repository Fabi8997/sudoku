import java.sql.*;
import javafx.collections.*;


public class ArchivioPartite {
    public ObservableList<Utente> lista;
    private final String nomeUtenteMYSQL;
    private final String passwordMYSQL;
    private final int numeroRighe;
    
    ArchivioPartite(DatiConfigurazione dati){
    
        nomeUtenteMYSQL = dati.nomeUtenteMYSQL;
        passwordMYSQL = dati.passwordMYSQL;
        numeroRighe = dati.numeroRigheArchivio;
        caricaClassifica();
    }
    
    public void caricaClassifica(){
        
    lista = FXCollections.observableArrayList();
        try ( Connection co = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudoku", nomeUtenteMYSQL , passwordMYSQL);
            PreparedStatement ps = co.prepareStatement("SELECT * FROM classifica ORDER BY punteggio DESC LIMIT ?");
        ){
            ps.setInt(1,numeroRighe);
            ResultSet rs = ps.executeQuery();
            int i = 1;
            while (rs.next()){
                lista.add(new Utente(rs.getString("nomeUtente"), rs.getInt("punteggio"), i++));  
              //System.out.println(rs.getString("nomeUtente") + " "+ rs.getInt("punteggio"))              
            }
                
        }catch (SQLException e) {System.err.println(e.getMessage());}
    
    }
    
    public void inserisciPartita(String nome, int punti){
        
        lista = FXCollections.observableArrayList();
        try ( Connection co = DriverManager.getConnection("jdbc:mysql://localhost:3306/sudoku", nomeUtenteMYSQL, passwordMYSQL);   
            PreparedStatement ps = co.prepareStatement("INSERT INTO classifica VALUES (?, ?)");
        ) { 
            ps.setString(1,nome); 
            ps.setInt(2,punti);
            System.out.println("rows affected: " + ps.executeUpdate()); 
            caricaClassifica();
      } catch (SQLException e) {System.err.println(e.getMessage());} 
    
    }
}
