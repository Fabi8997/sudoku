
import java.io.File;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;



public class EffettiSonori {
    
    private final String percorsoCorretto = "./myfiles/suoni/corretto.wav";// (1)
    private final String percorsoErrore ="./myfiles/suoni/errore.wav";
    private final String percorsoInizio = "./myfiles/suoni/start.wav";
    private final Media corretto;
    private final Media errore;
    private final Media inizio;
    private final MediaPlayer playerCorretto;
    private final MediaPlayer playerErrore;
    private final MediaPlayer playerInizio;
    public boolean attivo;
   
    EffettiSonori(){
    
        corretto = new Media(new File(percorsoCorretto).toURI().toString());
        errore = new Media(new File(percorsoErrore).toURI().toString());
        inizio = new Media(new File(percorsoInizio).toURI().toString());
    
        playerCorretto = new MediaPlayer(corretto);
        playerErrore = new MediaPlayer(errore);
        
        playerInizio = new MediaPlayer(inizio);
        
        attivo = true;
    }
    
    public void playCorretto(){   
        playerCorretto.stop();  //(2) 
        playerCorretto.play();
    }
    
    public void playErrore(){            
        playerErrore.stop();
        playerErrore.play();
    }
    
    public void playInizio(){         
        playerInizio.stop();
        playerInizio.play();
    }
    
    public void attivaDisattiva(){ // (03)
        
        if(attivo){
            playerInizio.setMute(true);
            playerErrore.setMute(true);
            playerInizio.setMute(true);
            attivo = false;
        }else{         
            playerInizio.setMute(false);
            playerErrore.setMute(false);
            playerInizio.setMute(false);
            attivo = true;
        }
    
    }
}


/*
Note:
(1) Suoni scaricati da https://mixkit.co/free-sound-effects/game/
(2) Resetta il mediaPlayer, altrimenti il suono viene eseguito una volta sola
(3) attiva o disattiva il suono in base alla variabile attivo 
*/