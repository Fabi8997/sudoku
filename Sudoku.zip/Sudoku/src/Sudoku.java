import javafx.application.*;
import javafx.collections.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.stage.*;

public class Sudoku extends Application {
    
    public static ArchivioPartite archivio;
    public static ConfigurazioneXML conf;
    public static EventoLogGui evento;
    private FinestraDiGioco finestra;
    private Partita partitaCorrente;
    private Timer cronometro;
    private EffettiSonori suono;
       
    @Override
    public void start(Stage stage) {
        
    conf = new ConfigurazioneXML();
    archivio = new ArchivioPartite(conf.configurazione);
    partitaCorrente = new Partita(conf.configurazione,(int)(Math.random()*conf.configurazione.campiDaGioco.length));
    evento = new EventoLogGui(conf.configurazione.ipServerLog, conf.configurazione.portaServer);
    finestra = new FinestraDiGioco(conf.configurazione,archivio.lista, partitaCorrente.campoDaGioco, partitaCorrente.dps);
    suono = new EffettiSonori();
    
    inizializzaEventi(stage);
    
    
    stage.setScene(finestra.scena);
    stage.setTitle("Sudoku");
    stage.show();
        
    }
    
    private void inizializzaEventi(Stage stage){
        evento.inviaEvento(new MessaggioDiLog(conf.configurazione.ipClient,"AVVIO"));
        eventiGrid();
        
        stage.setOnCloseRequest((WindowEvent we) -> {
            evento.inviaEvento(new MessaggioDiLog(conf.configurazione.ipClient,"TERMINA"));
            if(partitaCorrente.partitaIniziata)
                partitaCorrente.salvaPartita(cronometro.secondi, cronometro.minuti);
        });
        
        inserimentoUtente();
        
        finestra.aiuto.setOnAction( (ActionEvent e) -> {
            evento.inviaEvento(new MessaggioDiLog(conf.configurazione.ipClient,"AIUTO"));
            if(partitaCorrente.aiutoDisponibile && finestra.casellaCliccata!=null){
                suono.playCorretto();
                partitaCorrente.aiutoDisponibile = false;
                finestra.aiuto.setDisable(true);
                Integer colIndex = GridPane.getColumnIndex(finestra.casellaCliccata);
                Integer rowIndex = GridPane.getRowIndex(finestra.casellaCliccata);
                
                String s = Integer.toString(partitaCorrente.campoDaGioco.righeSoluzione[rowIndex].valori[colIndex]);
                finestra.casellaCliccata.setText(s);
                partitaCorrente.campoDaGioco.righeAttuali[rowIndex].valori[colIndex] = Integer.parseInt(s);
            }
        });        
        
        finestra.suoni.setOnAction( (ActionEvent e) -> {
            evento.inviaEvento(new MessaggioDiLog(conf.configurazione.ipClient,"MUSICA"));
            suono.attivaDisattiva();
            finestra.cambiaIconaSuono(suono.attivo);
        });
    }
    
    private void eventiGrid(){  // (1)
        
        ObservableList<Node> list = finestra.campoDaGioco.getChildren();
        for(Node node : list){
            
            node.setOnMouseClicked((Event e)->{    
                finestra.resetColori();
                Node clickedNode = (Node)e.getSource();
                TextField t = (TextField)clickedNode;
                Integer colIndex = GridPane.getColumnIndex(clickedNode);
                Integer rowIndex = GridPane.getRowIndex(clickedNode);
                finestra.coloraRigaColonna(rowIndex,colIndex,t.getText());
                if(t.getText().equals("") && partitaCorrente.aiutoDisponibile){
                    finestra.aiuto.setDisable(false);
                }else{
                    finestra.aiuto.setDisable(true);
                }
                finestra.casellaCliccata = t;
            });
            
            nuovoValore(node);
        }
    
    }
    
    private void nuovoValore(Node node){    // (2)
        
        node.setOnKeyPressed( (KeyEvent e) ->{
            if(e.getCode().toString().equals("ENTER")){
                evento.inviaEvento(new MessaggioDiLog(conf.configurazione.ipClient,"ENTER"));
                Node n = (Node)e.getSource();
                TextField t = (TextField)n;
                Integer colonna = GridPane.getColumnIndex(n); Integer riga = GridPane.getRowIndex(n);
                if(!partitaCorrente.valoreValido(riga,colonna,Integer.parseInt(t.getText()))){  
                    suono.playErrore();
                    t.setStyle("-fx-background-color: crimson; -fx-border-color: grey; -fx-font-weight: bold;");                   
                    t.setText("");
                    partitaCorrente.errori++;
                    finestra.errori.setText("Errori: " + partitaCorrente.errori + "/" + conf.configurazione.erroriConsentiti);
                    if(partitaCorrente.errori == conf.configurazione.erroriConsentiti){
                        finestra.coloraPersa();
                        cronometro.stopTempo();                           
                        partitaCorrente.partitaPersa = true;
                        finestra.inserimento.setDisable(false);
                    }else{
                        if(partitaCorrente.punteggio >= 300){                            
                            partitaCorrente.punteggio -= 300;
                        }                                               
                        finestra.punteggio.setText("Punteggio: " + partitaCorrente.punteggio);
                    }                       
                }else{
                    t.setStyle("-fx-background-color: forestgreen; -fx-border-color: grey; -fx-font-weight: bold;");
                    if(t.isEditable()){
                        suono.playCorretto();
                        partitaCorrente.punteggio += 100;
                        t.setEditable(false);
                        finestra.punteggio.setText("Punteggio: " + partitaCorrente.punteggio);
                    }
                        if(partitaCorrente.vittoria()){                       
                        int puntiFinali;
                        cronometro.stopTempo();
                        puntiFinali = partitaCorrente.punteggio - cronometro.minuti*240 - cronometro.secondi*4;
                        finestra.coloraVinta();                   
                        archivio.inserisciPartita(partitaCorrente.nomeUtente, puntiFinali);
                        finestra.punteggio.setText("Punteggio: " + puntiFinali);
                        
                    }
                }
            }
        }); 
    }
    
    
    private void inserimentoUtente(){   // (3)
            
        finestra.inserimento.setOnKeyPressed( (KeyEvent e) -> {            
            if(e.getCode().toString().equals("ENTER")){
                
                evento.inviaEvento(new MessaggioDiLog(conf.configurazione.ipClient,"ENTER"));
                
                if(!finestra.inserimento.getText().equals("")){
                    suono.playInizio();
                    partitaCorrente.partitaIniziata = true;
                    partitaCorrente.nomeUtente = finestra.inserimento.getText();
                
                    finestra.campoDaGioco.setDisable(false);
                    cronometro = new Timer(finestra.tempo);
                
                    if(!finestra.inserimento.getText().equals(partitaCorrente.dps.nomeUtente) || partitaCorrente.partitaPersa){
                        partitaCorrente.nuovaPartita(conf.configurazione,(int)(Math.random()*conf.configurazione.campiDaGioco.length));
                        finestra.aggiornaCampo(partitaCorrente.campoDaGioco);
                        cronometro.secondi = 0;
                        cronometro.minuti = 0;
                        //System.out.println("nome diverso");
                    }else if(finestra.inserimento.getText().equals(partitaCorrente.dps.nomeUtente) && partitaCorrente.partitaPersa){
                        cronometro.secondi = 0;
                        cronometro.minuti = 0;
                    }else{
                        cronometro.secondi = partitaCorrente.dps.secondi;           
                        cronometro.minuti = partitaCorrente.dps.minuti;
                    }
                    finestra.errori.setText("Errori: " + partitaCorrente.errori + "/" + conf.configurazione.erroriConsentiti);
                    finestra.punteggio.setText("Punteggio: " + partitaCorrente.punteggio);
                    finestra.inserimento.setDisable(true);
                    cronometro.startTempo();
                }
            }
        });
        
        }
        
}


/*
Note:
(1) Setta l'azione al click del mouse su ogni casella della gridPane
(2) Setta l'azione all'inserimento di un nuovo valore, gestisce l'incremento di
    errori, quando far partire i suoni e il termine della partita, sia in vittoria
    che in sconfitta
(3) Setta l'azione all'inserimento di un nuovo nome utente, verifica che sia 
    diversa da una stringa nulla, visualizza un suggerimento preso dalla cache
    qualora si voglia iniziare una partita precedentemente non terminata, ma dando
    la possibilità di iniziarne una nuova; fa partire il timer
*/