import java.io.File;
import javafx.collections.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;

public class FinestraDiGioco {
    
    public GridPane campoDaGioco;
    public Scene scena;
    public Label nomeUtente;
    public Label punteggio;
    public Label tempo;
    public Label errori;
    public Button aiuto;
    public Button suoni;
    public TextField casellaCliccata;
    public TextField inserimento;
    private final Group gruppo;    
    private final TableView<Utente> tabella;
    private VBox vbox;
    
    
    FinestraDiGioco(DatiConfigurazione conf, ObservableList<Utente> lista, Campo campo, DatiPartitaSalvata dati){
        campoDaGioco = new GridPane();
        tabella = new TableView<>();
        inizializzaCampo(campo);
        inizializzaClassifica(lista, conf.font);
        inizializzaSuoni();
        nomeUtente = new Label("Nome Utente:");
        nomeUtente.setLayoutX(293);
        nomeUtente.setStyle("-fx-font-weight: bold; -fx-font-family: " + conf.font);
        punteggio = new Label("Punteggio: " + dati.punteggioAttuale);
        punteggio.setLayoutX(130);
        punteggio.setStyle("-fx-font-weight: bold; -fx-font-family: " + conf.font);
        tempo = new Label("Tempo:");
        tempo.setLayoutY(265);
        tempo.setLayoutX(130);
        tempo.setStyle("-fx-font-weight: bold; -fx-font-family: " + conf.font);
        errori = new Label("Errori: " + dati.erroriAttuali + "/" + Integer.toString(conf.erroriConsentiti));
        errori.setLayoutX(5);
        errori.setStyle("-fx-font-weight: bold; -fx-text-fill: green; -fx-font-family: " + conf.font);
        setInserimento(dati);
        setAiuto();
        gruppo = new Group(suoni,vbox, inserimento, campoDaGioco, nomeUtente, punteggio, tempo, errori, aiuto);
        
        scena = new Scene(gruppo, 420, 300, Paint.valueOf(conf.coloreSfondo));
    }
    
    private void inizializzaCampo(Campo campo){
        
        campoDaGioco.setLayoutX(5);
        campoDaGioco.setLayoutY(20);
        for(int i = 0; i < 9; i++){
            for(int j = 0; j < 9; j++){
                TextField t;
                if((campo.righeAttuali[i].valori[j])==0){
                    t = new TextField("");
                    t.setEditable(true);
                }else{
                    t = new TextField(Integer.toString(campo.righeAttuali[i].valori[j]));
                    t.setEditable(false);
                    
                }
                
                if((i<3 && j<3) || (i<3 && j>5) || (i>2 && i<6 && j>2 && j<6) || (i>5 && j<3) || (i>5 && j>5))
                    t.setStyle("-fx-background-color: honeydew;  -fx-border-color: grey; -fx-font-weight: bold;");
                else
                    t.setStyle("-fx-background-color: antiquewhite; -fx-border-color: grey; -fx-font-weight: bold;");
                t.setMaxWidth(25);
                t.setMaxHeight(25);                  
                campoDaGioco.add(t,j,i);
            }
        }
        campoDaGioco.setDisable(true);
    }
    
    public void aggiornaCampo(Campo campo){ // (1)
        
        ObservableList<Node> list = campoDaGioco.getChildren();
        for(Node node : list){
            Integer row = GridPane.getRowIndex(node);
            Integer column = GridPane.getColumnIndex(node);  
            TextField t = (TextField)node;
            if((campo.righeAttuali[row].valori[column])==0){
                    t.setText("");
                    t.setEditable(true);
            }else{
                    t.setText(Integer.toString(campo.righeAttuali[row].valori[column]));
                    t.setEditable(false);
            }
           
        }
        errori.setStyle("-fx-font-weight: bold; -fx-text-fill: green;");
        tempo.setStyle("-fx-font-weight: bold;");
        punteggio.setStyle("-fx-font-weight: bold;");
        aiuto.setDisable(false);
        resetColori();
    
    }
    
    private void inizializzaClassifica(ObservableList<Utente> lista, String font){
        TableColumn posCol = new TableColumn("#"); 
        posCol.setMaxWidth(30);
        posCol.setCellValueFactory(new PropertyValueFactory<>("posizione")); 
        
        TableColumn nomeCol = new TableColumn("Nome"); 
        nomeCol.setMaxWidth(57);
        nomeCol.setCellValueFactory(new PropertyValueFactory<>("nomeUtente")); 

        TableColumn punteggioCol = new TableColumn("Punti"); 
        punteggioCol.setMaxWidth(57);
        punteggioCol.setCellValueFactory(new PropertyValueFactory<>("punteggio")); 
        
        final Label label = new Label("Classifica");
        label.setStyle("-fx-background-color: lightsalmon;"
                +  "-fx-border-color: grey;" 
                + " -fx-font-weight: bold;"
                + "; -fx-font-family: " + font);
                
        label.setMaxWidth(146);
        label.setAlignment(Pos.CENTER);
        
        tabella.setItems(lista);
        tabella.getColumns().addAll(posCol, nomeCol, punteggioCol); 

        vbox = new VBox(); 
        vbox.getChildren().addAll(label,tabella);
        vbox.setLayoutX(260);
        vbox.setLayoutY(60);
        vbox.setMaxWidth(146);
        vbox.setMaxHeight(200);
    }
    
    public void coloraRigaColonna(int i, int j, String val){
            //System.out.println(i + ":" + j + " " + val);
        ObservableList<Node> list = campoDaGioco.getChildren();
        for(Node node : list){
            Integer row = GridPane.getRowIndex(node);
            Integer column = GridPane.getColumnIndex(node);  
            TextField t = (TextField)node;
            String s = t.getText();
            if( (i == (int)row || j == (int)column)){
                node.setStyle("-fx-background-color: burlywood;  -fx-border-color: grey; -fx-font-weight: bold");     
            }
            if(!val.equals("") && (val.equals(s))){
                    //System.out.println(t.getText());
                    node.setStyle("-fx-background-color: cadetblue;"
                             + "-fx-border-color: grey;"
                             + "-fx-font-weight: bold;");
            }
        }
    }
    
    public void resetColori(){  // (2)
        ObservableList<Node> list = campoDaGioco.getChildren();
        for(Node node : list){
            Integer i = GridPane.getRowIndex(node);
            Integer j = GridPane.getColumnIndex(node);            
            if((i<3 && j<3) || (i<3 && j>5) || (i>2 && i<6 && j>2 && j<6) || (i>5 && j<3) || (i>5 && j>5))
                    node.setStyle("-fx-background-color: honeydew;  -fx-border-color: grey; -fx-font-weight: bold;");
                else
                    node.setStyle("-fx-background-color: antiquewhite; -fx-border-color: grey; -fx-font-weight: bold;");
        }
        
    
    }
    
    public void coloraPersa(){
        campoDaGioco.setDisable(true);
        errori.setStyle("-fx-font-weight: bold; -fx-text-fill: red;");
        tempo.setStyle("-fx-font-weight: bold; -fx-text-fill: red;");
        punteggio.setStyle("-fx-font-weight: bold; -fx-text-fill: red;");
        aiuto.setDisable(true); 
    }
    
    public void coloraVinta(){
        campoDaGioco.setDisable(true);
        errori.setStyle("-fx-font-weight: bold; -fx-text-fill: green;");
        tempo.setStyle("-fx-font-weight: bold; -fx-text-fill: green;");
        punteggio.setStyle("-fx-font-weight: bold; -fx-text-fill: green;");
        aiuto.setDisable(true); 
    }
    
    private void setInserimento(DatiPartitaSalvata dati){
        inserimento = new TextField();
        inserimento.setLayoutY(20);
        inserimento.setLayoutX(283);
        inserimento.setMaxWidth(100);
        inserimento.setText(dati.nomeUtente);
    }
    
    private void setAiuto(){
        aiuto = new Button("AIUTO");
        aiuto.setLayoutY(265);
        aiuto.setLayoutX(5);
        aiuto.setDisable(true);
    }

    private void inizializzaSuoni(){
        suoni = new Button();
        suoni.setLayoutY(265);
        suoni.setLayoutX(80);
        Image img = new Image(new File("./myfiles/immagini/audioattivo.png").toURI().toString()); // (3)
        ImageView icona = new ImageView(img);
        icona.setFitHeight(15);
        icona.setFitWidth(15);
        suoni.setMaxHeight(15);
        suoni.setMaxWidth(15);
        suoni.setGraphic(icona);
    }
    
    public void cambiaIconaSuono(boolean attivo){
        if(attivo){
            Image img = new Image(new File("./myfiles/immagini/audioattivo.png").toURI().toString());
            ImageView icona = new ImageView(img);
            icona.setFitHeight(15);
            icona.setFitWidth(15);
            suoni.setGraphic(icona);
        }else{
            Image img = new Image(new File("./myfiles/immagini/audiooff.png").toURI().toString());
            ImageView icona = new ImageView(img);
            icona.setFitHeight(15);
            icona.setFitWidth(15);
            suoni.setGraphic(icona);
        }
    }
}


/*
Note:
(1) Aggiorna il campo da gioco dato un nuovo campo passato come parametro, serve
    dopo una partita persa o quando si vuole iniziare una nuova partita dopo una 
    vittoria
(2) Resetta i colori come se il campo da gioco fosse appena avviato, serve per 
    togliere la riga e la colonna evidenziate
(3) Immagini prese da www.pngwing.com

*/