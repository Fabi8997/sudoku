import com.thoughtworks.xstream.*;
import java.io.*;
import java.nio.file.*;
import javax.xml.*;
import javax.xml.parsers.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import javax.xml.validation.*;
import org.w3c.dom.*;
import org.xml.sax.*;


public class ConfigurazioneXML {
    private final String percorsoXML = "./myfiles/config.xml";
    private final String percorsoXSD = "./myfiles/config.xsd";
    public DatiConfigurazione configurazione;
    
    ConfigurazioneXML(){
       configurazione = new DatiConfigurazione();
       validaXML();
       deserializzaXML();
    }
    
    private void deserializzaXML(){
        
    XStream xs = new XStream();
    String x = new String(); 
    try {   
        x = new String(Files.readAllBytes(Paths.get(percorsoXML)));       
     }  catch (Exception e) {}    
    
        configurazione = (DatiConfigurazione)xs.fromXML((x));
    }
    
    private void validaXML(){
         
        try {  
            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder(); 
            SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Document d = db.parse(new File(percorsoXML)); 
            Schema s = sf.newSchema(new StreamSource(new File(percorsoXSD)));
            s.newValidator().validate(new DOMSource(d));
        } catch (Exception e) {
            if (e instanceof SAXException) 
                System.out.println("Errore di validazione: " + e.getMessage());
            else
                System.out.println(e.getMessage());    
        }  
    }  
    
}
