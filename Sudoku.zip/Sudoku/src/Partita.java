public class Partita {
    private final int erroriConsentiti;
    private final PartitaSalvata ps;
    public Campo campoDaGioco;
    public int punteggio;
    public int errori;
    public boolean aiutoDisponibile;
    public boolean partitaPersa;
    public boolean partitaCompletata;
    public boolean partitaIniziata;
    public String nomeUtente;     
    public DatiPartitaSalvata dps;
    
    
    Partita(DatiConfigurazione conf, int val){
        
        ps = new PartitaSalvata(conf.percorsoCache);
        dps = caricaPartita();
        
        partitaIniziata = false;
        
        erroriConsentiti = conf.erroriConsentiti;   
        if(dps.datiValidi && partitaPersa == false){    // (1)            
            punteggio = dps.punteggioAttuale;
            errori = dps.erroriAttuali;
            aiutoDisponibile = dps.aiutoAttuale;            
            campoDaGioco = dps.campoAttuale;    
            partitaPersa = false;
            partitaCompletata = false;
        }else{
            punteggio = 0;
            errori = 0;
            aiutoDisponibile = true;
            campoDaGioco = conf.campiDaGioco[val];    
            partitaCompletata = false;
            partitaPersa = false;
        }
        
       
    }
    
    public boolean valoreValido(int i, int j, int v){    // (2)
        return campoDaGioco.inserisciValore(v, i, j);
        
    }
    
    public boolean vittoria(){
        if(campoDaGioco.campoCompletato()){
            partitaCompletata = true;
            return true;
        }
        return campoDaGioco.campoCompletato();
    }
    
    private DatiPartitaSalvata caricaPartita(){
        DatiPartitaSalvata dati = ps.caricaPartitaBin();
        return dati;
    }
    
    public void salvaPartita(int s, int m){
        DatiPartitaSalvata dati = new DatiPartitaSalvata();
        dati.nomeUtente = nomeUtente;
        dati.aiutoAttuale = aiutoDisponibile;
        dati.campoAttuale = campoDaGioco;
        if(partitaPersa)
           dati.datiValidi = false;
        else
           dati.datiValidi = !partitaCompletata;
        dati.erroriAttuali = errori;
        dati.secondi = s;
        dati.minuti = m;
        dati.punteggioAttuale = punteggio;
        if(partitaCompletata || partitaPersa)
            ps.salvaPartitaBin(new DatiPartitaSalvata());
        else
            ps.salvaPartitaBin(dati);
    }
    
    public void nuovaPartita(DatiConfigurazione conf, int val){
        punteggio = 0;
        errori = 0;
        aiutoDisponibile = true;
        campoDaGioco = conf.campiDaGioco[val];   
        partitaCompletata = false;
        partitaPersa = false;
    
    }
}


/*
Note:
(1) Controllo se usare i dati salvati in cache, altrimenti inizializza come fosse
    una nuova partita, poichè alla chiusura della precedente partita si è registrata
    una vittoria o una sconfitta

(2) Usa il metodo di campo per provare ad inserire il valore nella riga i e 
    colonna j, restituendo l'esito dell'operazione
*/